OSX_ARCHITECTURES_<CONFIG>
--------------------------

Per-configuration macOS and iOS binary architectures for a target.

This property is the configuration-specific version of
:prop_tgt:`OSX_ARCHITECTURES`.
