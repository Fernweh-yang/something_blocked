NAME
----

Logical name for the target.

Read-only logical name for the target as used by CMake.
